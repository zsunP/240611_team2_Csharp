﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test1
{

    //중량
    public class MeltWeightStats
    {
        public double AvgWeight { get; set; }
        public double MedianWeight { get; set; }
        public double ModeWeight { get; set; }
    }
}
