﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test1
{
    //수분 함유량
    public class MoistureContentStats
    {
        public double AvgMoisture { get; set; }
        public double MedianMoisture { get; set; }
        public double ModeMoisture { get; set; }

    }
}
