﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test1
{
    public class MotorSpeedStats
    {
        public double AvgSpeed { get; set; }
        public double MedianSpeed { get; set; }
        public double ModeSpeed { get; set; }
    }
}
