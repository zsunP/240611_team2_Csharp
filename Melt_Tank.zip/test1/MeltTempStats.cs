﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test1
{

    //온도
    public class MeltTempStats
    {
        public double MaxTemp { get; set; }
        public double MinTemp { get; set; }
        public double ModeTemp { get; set; }
    }
}
