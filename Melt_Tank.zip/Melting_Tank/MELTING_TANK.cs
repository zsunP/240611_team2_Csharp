﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Melting_Tank
{
    internal class MELTING_TANK
    {
        public DateTime STD_DT { get; set; }

        public int NUM { get; set; }

        public int MELT_TEMP { get; set; }

        public int MOTORSPEED { get; set; }

        public int MELT_WEIGHT { get; set; }

        public float INSP { get; set; }

        public bool TAG { get; set; }

    }
}
