﻿namespace Melting_Tank
{
    partial class Form_Chart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Chart));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label_Time = new System.Windows.Forms.Label();
            this.label_title = new System.Windows.Forms.Label();
            this.label_selctword = new System.Windows.Forms.Label();
            this.comboBox_Date = new System.Windows.Forms.ComboBox();
            this.chart_view = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.comboBox_Time = new System.Windows.Forms.ComboBox();
            this.dataGridView_select = new System.Windows.Forms.DataGridView();
            this.button_Temp = new System.Windows.Forms.Button();
            this.button_Motorspeed = new System.Windows.Forms.Button();
            this.button_MELT_WEIGHT = new System.Windows.Forms.Button();
            this.button_INSP = new System.Windows.Forms.Button();
            this.button_Max = new System.Windows.Forms.Button();
            this.button_Min = new System.Windows.Forms.Button();
            this.label_analys_over = new System.Windows.Forms.Label();
            this.label_analys_low = new System.Windows.Forms.Label();
            this.textBox_search_over = new System.Windows.Forms.TextBox();
            this.textBox_search_low = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.chart_view)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_select)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label_Time
            // 
            this.label_Time.AutoSize = true;
            this.label_Time.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_Time.Location = new System.Drawing.Point(12, 9);
            this.label_Time.Name = "label_Time";
            this.label_Time.Size = new System.Drawing.Size(0, 15);
            this.label_Time.TabIndex = 0;
            // 
            // label_title
            // 
            this.label_title.AutoSize = true;
            this.label_title.Font = new System.Drawing.Font("에스코어 드림 5 Medium", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_title.Location = new System.Drawing.Point(279, 26);
            this.label_title.Name = "label_title";
            this.label_title.Size = new System.Drawing.Size(375, 33);
            this.label_title.TabIndex = 1;
            this.label_title.Text = "불량률 감소를 위한 데이터시각화";
            // 
            // label_selctword
            // 
            this.label_selctword.AutoSize = true;
            this.label_selctword.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_selctword.Location = new System.Drawing.Point(228, 94);
            this.label_selctword.Name = "label_selctword";
            this.label_selctword.Size = new System.Drawing.Size(127, 15);
            this.label_selctword.TabIndex = 2;
            this.label_selctword.Text = "날짜를선택하세요";
            // 
            // comboBox_Date
            // 
            this.comboBox_Date.FormattingEnabled = true;
            this.comboBox_Date.Location = new System.Drawing.Point(398, 94);
            this.comboBox_Date.Name = "comboBox_Date";
            this.comboBox_Date.Size = new System.Drawing.Size(142, 20);
            this.comboBox_Date.TabIndex = 3;
            // 
            // chart_view
            // 
            chartArea1.Name = "ChartArea1";
            this.chart_view.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart_view.Legends.Add(legend1);
            this.chart_view.Location = new System.Drawing.Point(104, 248);
            this.chart_view.Name = "chart_view";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart_view.Series.Add(series1);
            this.chart_view.Size = new System.Drawing.Size(800, 276);
            this.chart_view.TabIndex = 4;
            this.chart_view.Text = "chart1";
            // 
            // comboBox_Time
            // 
            this.comboBox_Time.FormattingEnabled = true;
            this.comboBox_Time.Location = new System.Drawing.Point(555, 93);
            this.comboBox_Time.Name = "comboBox_Time";
            this.comboBox_Time.Size = new System.Drawing.Size(160, 20);
            this.comboBox_Time.TabIndex = 5;
            // 
            // dataGridView_select
            // 
            this.dataGridView_select.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_select.Location = new System.Drawing.Point(104, 547);
            this.dataGridView_select.Name = "dataGridView_select";
            this.dataGridView_select.RowTemplate.Height = 23;
            this.dataGridView_select.Size = new System.Drawing.Size(800, 195);
            this.dataGridView_select.TabIndex = 6;
            // 
            // button_Temp
            // 
            this.button_Temp.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_Temp.Location = new System.Drawing.Point(222, 155);
            this.button_Temp.Name = "button_Temp";
            this.button_Temp.Size = new System.Drawing.Size(106, 35);
            this.button_Temp.TabIndex = 7;
            this.button_Temp.Text = "MELT_TEMP";
            this.button_Temp.UseVisualStyleBackColor = true;
            // 
            // button_Motorspeed
            // 
            this.button_Motorspeed.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_Motorspeed.Location = new System.Drawing.Point(347, 155);
            this.button_Motorspeed.Name = "button_Motorspeed";
            this.button_Motorspeed.Size = new System.Drawing.Size(108, 35);
            this.button_Motorspeed.TabIndex = 8;
            this.button_Motorspeed.Text = "MOTORSPEED";
            this.button_Motorspeed.UseVisualStyleBackColor = true;
            // 
            // button_MELT_WEIGHT
            // 
            this.button_MELT_WEIGHT.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_MELT_WEIGHT.Location = new System.Drawing.Point(493, 155);
            this.button_MELT_WEIGHT.Name = "button_MELT_WEIGHT";
            this.button_MELT_WEIGHT.Size = new System.Drawing.Size(121, 35);
            this.button_MELT_WEIGHT.TabIndex = 9;
            this.button_MELT_WEIGHT.Text = "MELT_WEIGHT";
            this.button_MELT_WEIGHT.UseVisualStyleBackColor = true;
            // 
            // button_INSP
            // 
            this.button_INSP.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_INSP.Location = new System.Drawing.Point(620, 155);
            this.button_INSP.Name = "button_INSP";
            this.button_INSP.Size = new System.Drawing.Size(95, 35);
            this.button_INSP.TabIndex = 10;
            this.button_INSP.Text = "INSP";
            this.button_INSP.UseVisualStyleBackColor = true;
            // 
            // button_Max
            // 
            this.button_Max.Location = new System.Drawing.Point(878, 53);
            this.button_Max.Name = "button_Max";
            this.button_Max.Size = new System.Drawing.Size(75, 23);
            this.button_Max.TabIndex = 11;
            this.button_Max.Text = "최대값표시";
            this.button_Max.UseVisualStyleBackColor = true;
            // 
            // button_Min
            // 
            this.button_Min.Location = new System.Drawing.Point(878, 92);
            this.button_Min.Name = "button_Min";
            this.button_Min.Size = new System.Drawing.Size(75, 23);
            this.button_Min.TabIndex = 12;
            this.button_Min.Text = "최소값표시";
            this.button_Min.UseVisualStyleBackColor = true;
            // 
            // label_analys_over
            // 
            this.label_analys_over.AutoSize = true;
            this.label_analys_over.Location = new System.Drawing.Point(899, 131);
            this.label_analys_over.Name = "label_analys_over";
            this.label_analys_over.Size = new System.Drawing.Size(38, 12);
            this.label_analys_over.TabIndex = 13;
            this.label_analys_over.Text = "label1";
            // 
            // label_analys_low
            // 
            this.label_analys_low.AutoSize = true;
            this.label_analys_low.Location = new System.Drawing.Point(899, 196);
            this.label_analys_low.Name = "label_analys_low";
            this.label_analys_low.Size = new System.Drawing.Size(38, 12);
            this.label_analys_low.TabIndex = 14;
            this.label_analys_low.Text = "label2";
            // 
            // textBox_search_over
            // 
            this.textBox_search_over.Location = new System.Drawing.Point(890, 155);
            this.textBox_search_over.Name = "textBox_search_over";
            this.textBox_search_over.Size = new System.Drawing.Size(125, 21);
            this.textBox_search_over.TabIndex = 15;
            // 
            // textBox_search_low
            // 
            this.textBox_search_low.Location = new System.Drawing.Point(890, 221);
            this.textBox_search_low.Name = "textBox_search_low";
            this.textBox_search_low.Size = new System.Drawing.Size(125, 21);
            this.textBox_search_low.TabIndex = 16;
            // 
            // Form_Chart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1048, 764);
            this.Controls.Add(this.textBox_search_low);
            this.Controls.Add(this.textBox_search_over);
            this.Controls.Add(this.label_analys_low);
            this.Controls.Add(this.label_analys_over);
            this.Controls.Add(this.button_Min);
            this.Controls.Add(this.button_Max);
            this.Controls.Add(this.button_INSP);
            this.Controls.Add(this.button_MELT_WEIGHT);
            this.Controls.Add(this.button_Motorspeed);
            this.Controls.Add(this.button_Temp);
            this.Controls.Add(this.dataGridView_select);
            this.Controls.Add(this.comboBox_Time);
            this.Controls.Add(this.chart_view);
            this.Controls.Add(this.comboBox_Date);
            this.Controls.Add(this.label_selctword);
            this.Controls.Add(this.label_title);
            this.Controls.Add(this.label_Time);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_Chart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form_Chart";
            ((System.ComponentModel.ISupportInitialize)(this.chart_view)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_select)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label_Time;
        private System.Windows.Forms.Label label_title;
        private System.Windows.Forms.Label label_selctword;
        private System.Windows.Forms.ComboBox comboBox_Date;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_view;
        private System.Windows.Forms.ComboBox comboBox_Time;
        private System.Windows.Forms.DataGridView dataGridView_select;
        private System.Windows.Forms.Button button_Temp;
        private System.Windows.Forms.Button button_Motorspeed;
        private System.Windows.Forms.Button button_MELT_WEIGHT;
        private System.Windows.Forms.Button button_INSP;
        private System.Windows.Forms.Button button_Max;
        private System.Windows.Forms.Button button_Min;
        private System.Windows.Forms.Label label_analys_over;
        private System.Windows.Forms.Label label_analys_low;
        private System.Windows.Forms.TextBox textBox_search_over;
        private System.Windows.Forms.TextBox textBox_search_low;
    }
}